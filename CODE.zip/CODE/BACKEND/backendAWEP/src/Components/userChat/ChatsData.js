export const ChatsData = [
  {
    customerName: "Benish Zahra",
    customerAvatar: "https://source.unsplash.com/mEZ3PoFGs_k/",
    messageBrief: "Experience is Good",
    messageTime: "11:30",
    path: "chat/alonsoMosely",
  },
  {
    customerName: "Sarah Nasir",
    customerAvatar: "https://source.unsplash.com/u3WmDyKGsrY/",
    messageBrief: "The site is amazing to shop it has many vendor",
    messageTime: "12:30",
  },
  {
    customerName: "Muhammad Talha",
    customerAvatar: "https://source.unsplash.com/i4OHxtxiMtk/",
    messageBrief: "Hi There!",
    messageTime: "12:30",
  },
  {
    customerName: "Syed Ali Hassan Zaidi",
    customerAvatar: "https://source.unsplash.com/ILip77SbmOE/",
    messageBrief: "Hi There!",
    messageTime: "15:30",
  },
  {
    customerName: "Tehseen Riaz Abbasi",
    customerAvatar: "https://source.unsplash.com/7YVZYZeITc8/",
    messageBrief: "Hi There!",
    messageTime: "17:30",
  },
];
