export const AlonsoMoselyChatData = [
  {
    message: `great experience very good quality responsive seller heavy weight mouse perfect for gaming
    wire quality is great
    fast delivery
    recommended fr everyone ❤️`,
    sentDate: "5/30/2022",
    sentTime: "11:38pm",
  },
  {
    message: `great experience very good quality responsive seller heavy weight mouse perfect for gaming
    wire quality is great
    fast delivery
    recommended fr everyone ❤️`,
    sentDate: "5/30/2022",
    sentTime: "11:38pm",
  },
  {
    message: `great experience very good quality responsive seller heavy weight mouse perfect for gaming
    wire quality is great
    fast delivery
    recommended fr everyone ❤️`,
    sentDate: "5/30/2022",
    sentTime: "11:38pm",
  },
  {
    message: `great experience very good quality responsive seller heavy weight mouse perfect for gaming
    wire quality is great
    fast delivery
    recommended fr everyone ❤️`,
    sentDate: "5/30/2022",
    sentTime: "11:38pm",
  },
];
