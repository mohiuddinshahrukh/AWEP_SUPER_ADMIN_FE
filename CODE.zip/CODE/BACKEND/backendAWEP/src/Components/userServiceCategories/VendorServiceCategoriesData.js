export const VendorServiceCategoriesData = [
  {
    title: "DJ & Music",
    path: "dj&music",
    img: "https://source.unsplash.com/ATeFbve78Zo/1300x710",
  },
  {
    title: "Photography",
    path: "photography",
    img: "https://source.unsplash.com/6NHyiqGlP1Q/1300x710",
  },
  {
    title: "Birdal Makeover",
    path: "",
    img: "https://source.unsplash.com/FoeIOgztCXo/600x300",
  },
  {
    title: "Stage Decor",
    path: "",
    img: "https://source.unsplash.com/0ci9am-l-Dk/600x300)",
  },
  {
    title: "Car Rental",
    path: "",
    img: "https://source.unsplash.com/aZKJEvydrNM/600x300)",
  },
  {
    title: "Videography",
    path: "",
    img: "https://source.unsplash.com/9ESAufvpgjI/600x300)",
  },
  {
    title: "Marriage Registrar",
    path: "",
    img: "https://source.unsplash.com/YeJWDWeIZho/600x300)",
  },
];
