import React from "react";

const PendingBookingsTable = () => {
  return <div>PendingBookingsTable</div>;
};

export default PendingBookingsTable;
