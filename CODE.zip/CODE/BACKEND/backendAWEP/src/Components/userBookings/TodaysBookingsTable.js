import React from "react";

const TodaysBookingsTable = () => {
  return <div>TodaysBookingsTable</div>;
};

export default TodaysBookingsTable;
